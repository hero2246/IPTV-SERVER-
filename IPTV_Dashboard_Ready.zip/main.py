from flask import Flask, request, jsonify, render_template_string, redirect, url_for, session
from datetime import datetime, timedelta
import json
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"

CLIENTS_FILE = "clients.json"
M3U_TEMPLATE = "https://exemple.com/iptv/{{username}}.m3u8"
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

if not os.path.exists(CLIENTS_FILE):
    with open(CLIENTS_FILE, 'w') as f:
        json.dump({}, f)

with open(CLIENTS_FILE, 'r') as f:
    clients = json.load(f)

LOGIN_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head><title>Connexion Admin</title></head>
<body>
    <h2>Connexion Administrateur</h2>
    <form method="post">
        Nom d'utilisateur: <input type="text" name="username"><br>
        Mot de passe: <input type="password" name="password"><br>
        <input type="submit" value="Se connecter">
    </form>
</body>
</html>
'''

DASHBOARD_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard IPTV</title>
</head>
<body>
    <h1>Ajouter un client IPTV</h1>
    <form action="/add" method="post">
        Nom d'utilisateur: <input type="text" name="username"><br>
        Durée (jours): <input type="number" name="days" value="30"><br>
        <input type="submit" value="Générer le lien">
    </form>
    <h2>Liste des clients</h2>
    <ul>
        {% for user, data in clients.items() %}
        <li><strong>{{ user }}</strong> - Expire le {{ data['expire_at'] }} - <a href="{{ data['iptv_link'] }}">Lien</a>
            - <form action="/delete/{{ user }}" method="post" style="display:inline;"><button type="submit">Supprimer</button></form>
        </li>
        {% endfor %}
    </ul>
    <hr>
    <h3>Tester gratuitement 24h</h3>
    <form action="/test" method="post">
        Nom: <input type="text" name="username"><br>
        <input type="submit" value="Activer l'essai gratuit">
    </form>
    <hr>
    <h3>Paiement</h3>
    <p>
        <a href="https://www.paypal.com/paypalme/votre_compte" target="_blank">Payer avec PayPal</a><br>
        <strong>Orange Money / Wave :</strong> Envoyez le paiement à ce numéro : <b>+221 77 123 45 67</b><br>
        Une fois payé, contactez-nous via WhatsApp pour activer votre lien IPTV.
    </p>
    <hr>
    <p><a href="/logout">Déconnexion</a></p>
</body>
</html>
'''

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['logged_in'] = True
            return redirect(url_for("home"))
        else:
            return "Identifiants incorrects"
    return LOGIN_TEMPLATE

@app.route("/logout")
def logout():
    session.pop('logged_in', None)
    return redirect(url_for("login"))

@app.route("/")
def home():
    if not session.get('logged_in'):
        return redirect(url_for("login"))
    return render_template_string(DASHBOARD_TEMPLATE, clients=clients)

@app.route("/add", methods=["POST"])
def add_client():
    if not session.get('logged_in'):
        return redirect(url_for("login"))
    username = request.form.get("username")
    days = int(request.form.get("days", 30))
    expire_at = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
    iptv_link = M3U_TEMPLATE.replace("{{username}}", username)

    clients[username] = {
        "iptv_link": iptv_link,
        "expire_at": expire_at
    }

    with open(CLIENTS_FILE, 'w') as f:
        json.dump(clients, f, indent=4)

    return redirect(url_for("home"))

@app.route("/test", methods=["POST"])
def free_test():
    username = request.form.get("username")
    expire_at = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    iptv_link = M3U_TEMPLATE.replace("{{username}}", username)

    clients[username] = {
        "iptv_link": iptv_link,
        "expire_at": expire_at
    }

    with open(CLIENTS_FILE, 'w') as f:
        json.dump(clients, f, indent=4)

    return f"Essai activé pour {username} - Lien: {iptv_link} (valide 24h)"

@app.route("/api/client/<username>", methods=["GET"])
def get_client(username):
    client = clients.get(username)
    if client:
        if datetime.strptime(client["expire_at"], "%Y-%m-%d") >= datetime.now():
            return jsonify(client)
        else:
            return jsonify({"error": "Lien expiré"}), 403
    return jsonify({"error": "Client introuvable"}), 404

@app.route("/delete/<username>", methods=["POST"])
def delete_client(username):
    if not session.get('logged_in'):
        return redirect(url_for("login"))
    if username in clients:
        del clients[username]
        with open(CLIENTS_FILE, 'w') as f:
            json.dump(clients, f, indent=4)
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)